#!/bin/bash

esFeriado(){
	fecha=$1
	feriados=( "01-01" "03-24" "04-02" "05-01" "05-25" "06-20" "07-09" "08-17" "10-12" "11-10" "12-08" "12-25" )

	dia_semana=$(date -d "$fecha" +%u)
	mes_dia=$(date -d "$fecha" +%m-%d)

	if [ $dia_semana -eq 6 ] || [ $dia_semana -eq 7 ]; then
		echo "La fecha $fecha es un fin de semana, no es laborable."
		return 1
	fi
	for feriado in "${feriados[@]}"; do
		if [ "$mes_dia" == "$feriado" ]; then
			echo "La fecha $fecha es un feriado en Argentina: $feriado."
			return 1
		fi
	done
	echo "La fecha $fecha es laborable."
	return 0
}
