#!/bin/bash

source esLaborable.sh

esFeriado "2023-04-04"
esFeriado "2023-01-01"
esFeriado "2023-02-02"
esFeriado "2023-03-03"
esFeriado "2023-03-24"

